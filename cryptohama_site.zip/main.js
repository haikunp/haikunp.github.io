document.addEventListener('DOMContentLoaded', () => {
  const cardData = { casinos: [], exchanges: [], faucets: [], games: [] }; // Truncated sample data

  function generateStars(rating) {
    const full = '★'.repeat(Math.floor(rating));
    const half = rating % 1 >= 0.5 ? '½' : '';
    return full + half;
  }

  function generateCards() {
    Object.keys(cardData).forEach(category => {
      const grid = document.querySelector(`#${category} .card-grid`);
      grid.innerHTML = cardData[category].map((item, index) => \`
        <div class="card-wrapper">
          <div class="rank-badge">\${index + 1}</div>
          <div class="card">
            <div class="card-header">
              <div class="card-icon">\${item.title.charAt(0)}</div>
              <div>
                <h3 class="card-title">\${item.title}</h3>
                <p class="card-subtitle">\${item.subtitle}</p>
              </div>
            </div>
            <div class="card-rating">
              <div class="stars">\${generateStars(item.rating)}</div>
              <div class="rating-value">\${item.rating}/5</div>
            </div>
            <ul class="card-features">
              \${item.features.map(f => `<li>\${f}</li>`).join('')}
            </ul>
            <div class="card-footer">
              <div class="bonus-badge">\${item.bonus}</div>
              <a href="#" class="visit-button"><i class="fas fa-external-link-alt"></i> Visit</a>
            </div>
          </div>
        </div>
      \`).join('');
    });
  }

  function switchTab(tabId) {
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.querySelector(`.tab-button[data-tab="\${tabId}"]`).classList.add('active');
    document.getElementById(tabId).classList.add('active');
    history.replaceState(null, '', `#\${tabId}`);
  }

  function initTabs() {
    const hash = location.hash.replace('#', '') || 'casinos';
    switchTab(hash);
    document.querySelectorAll('.tab-button').forEach(button => {
      button.addEventListener('click', () => switchTab(button.dataset.tab));
    });
  }

  initTabs();
  generateCards();
});